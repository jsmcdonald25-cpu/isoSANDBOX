# GrailISO SPRINGBOARD — Session 5 Handoff
**Generated:** 2026-03-13  
**Build:** GrailISO_v1.1.7 :: STABLE  
**File:** dashboard.html (4337 lines, 113 functions)

---

## WHAT WAS FIXED THIS SESSION

### 1. Card rows not clickable (ROOT CAUSE CHAIN)
- Event delegation on `#ivCardList` was correct
- `_ivApplyCardFilters()` called immediately (not gated on market price promise) — was fixed last session
- **Actual root cause found this session:** stray lone `,` on its own line between id:48 and id:50 in the `CARDS` array → created a sparse `undefined` slot → `CARDS.find(c => c._cardNumber...)` crashed immediately on the undefined entry
- Fix: removed stray comma, added `c &&` null guard in both `CARDS.find()` calls (ivOpenCard + openCardDetail)

### 2. Card image not showing on click
- ISOVault row stores `card_number: 135` (DB row number)
- CARDS entry for Griffey has `_cardNumber: 'SS-24'`
- `_cdLoadCatalogImages` was querying `.eq('card_number', 'SS-24')` → no match
- Fix: `ivOpenCard` now stashes `window._cdOverrideCardNum` and `window._cdOverrideVarImages` from the clicked row before calling `openCardDetail`
- `_cdLoadCatalogImages` checks `_cdOverrideVarImages` first — uses preloaded data directly, no second query needed

### 3. showToast was wrong function name
- Real function is `T(msg)` at line ~1889
- Replaced all `showToast(...)` calls with `T(...)`

---

## CURRENT STATE — CONFIRMED WORKING
- ✅ ISOVault click → card detail opens
- ✅ Griffey SS-24 image shows on click (preloaded from row)
- ✅ All 18 variation pills on Griffey
- ✅ Event delegation on card rows (list + grid)
- ✅ `_ivApplyCardFilters()` called immediately on set load
- ✅ Password gate (grail2026)
- ✅ Static sidebar nav
- ✅ Community slide-in panel
- ✅ Scores bar
- ✅ Card ticker
- ✅ Vault modal dual path (upload vs catalog pic)
- ✅ Live market price engine per variation
- ✅ ±40% price anomaly detection (silent)
- ✅ Admin price flag dashboard
- ✅ Error report modal (5-credit finder's fee)

---

## DEBUG LOGGING STILL IN PLACE (clean up when done)
These console.log lines are still in the file — remove before production:
- `[IV] click fired` in `_ivRenderChecklist` onclick handler (~line 3522)
- `[IV] grid click` in `_ivRenderGrid` onclick handler (~line 3551)  
- `[IV] ivOpenCard called with:` at start of `ivOpenCard`
- `[CD] preloaded var_images keys:` in `_cdLoadCatalogImages`
- `[CD] query table:` in `_cdLoadCatalogImages`
- Try/catch error traps with `T('❌ ...')` in click handlers — can stay or go

---

## PENDING SQL MIGRATIONS (not yet run)
```sql
ALTER TABLE vault ADD COLUMN IF NOT EXISTS variation text;
ALTER TABLE vault ADD COLUMN IF NOT EXISTS market_excluded boolean DEFAULT false;

CREATE TABLE price_flags (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  vault_id uuid REFERENCES vault(id),
  user_id uuid, card_number text, card_name text, set_table text, variation text,
  price_submitted numeric, market_avg numeric, deviation_pct numeric,
  direction text, status text DEFAULT 'pending', flagged_at timestamptz DEFAULT now(),
  resolved_at timestamptz, admin_corrected_price numeric, user_corrected_price numeric, email_sent_at timestamptz
);

CREATE TABLE price_flag_emails (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  flag_id uuid, vault_id uuid, user_id uuid, card_name text, variation text,
  price_submitted numeric, market_avg numeric, sent_at timestamptz, status text DEFAULT 'sent'
);

CREATE TABLE error_reports (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  card_name text, card_number text, set_table text, variation text,
  note text, status text DEFAULT 'pending', reported_at timestamptz DEFAULT now()
);
```

---

## PENDING ITEMS
- Replace Discord placeholder URLs in community panel:
  - `https://discord.gg/BASEBALL_LINK`
  - `https://discord.gg/BASKETBALL_LINK`
  - `https://discord.gg/FOOTBALL_LINK`
  - `https://discord.gg/HOCKEY_LINK`
- Remove debug console.log lines before production
- `/admin/fomo` dashboard — **DO NOT BUILD YET**

---

## KEY CONSTANTS
```
Supabase URL:     https://jyfaegmnzkarlcximxjo.supabase.co
Supabase Key:     sb_publishable_-JI4Y3ImXzqRVkwx1yIL1g_rVJVx5bn
Supabase Client:  window._sb
Storage bucket:   card-images
Password:         grail2026
Build stamp fmt:  [SYS] GrailISO_v1.1.7 :: BUILD {YYYYMMDD} {HH:MM} :: STABLE
```

## IV_SETS
```javascript
{ table:'2026_series1_baseball',  sport:'baseball', year:2026, brand:'Topps', name:'Series 1',     label:'2026 Topps Series 1'  }
{ table:'2026_heritage_baseball', sport:'baseball', year:2026, brand:'Topps', name:'Heritage',     label:'2026 Topps Heritage'  }
{ table:'2025_stadium_club_v2',   sport:'baseball', year:2025, brand:'Topps', name:'Stadium Club', label:'2025 Stadium Club'    }
```
