# GrailISO — PROJECT.md
**Last updated:** 2026-03-13  
**Status:** Active Development — Preview Build

---

## WHAT IS GRAILISO
A sports card platform. Users post cards for ISO (In Search Of), match with sellers, track their vault, and browse a comprehensive card catalog. The ISOVault is the world's most complete sports card search engine — Sport → Year → Brand → Set → Checklist → Card Detail.

---

## PERMANENT DESIGN SYSTEM — NEVER CHANGE

| Token | Value |
|---|---|
| Background | `#0D1F33` — every page, no exceptions |
| GRAIL color | `#FFFFFF` |
| ISO color | `#00AAFF` |
| Headline font | Bebas Neue |
| UI font | Barlow Condensed |
| Red / error | `#FF3B5C` |
| Green / success | `#00E887` |

---

## PERMANENT RULES

1. `card-viewer.html` — **NEVER MODIFY under any circumstances**
2. FOMO Engine — **real data only**, no fake timers, no fabricated urgency ever
3. `/admin/fomo` dashboard — **DO NOT BUILD YET**
4. At 190,000 tokens — STOP, generate SPRINGBOARD.md + PROJECT.md, tell user to open new thread
5. **Only do exactly what is asked. Nothing more. Never add unrequested features.**
6. Toast function is `T(msg)` — not `showToast`, not `toast`

---

## TECH STACK

- **Frontend:** Single-file HTML/CSS/JS (`dashboard.html`)
- **Backend:** Supabase (Postgres + Storage)
- **Auth:** Supabase Auth (session-based)
- **Images:** Supabase Storage bucket `card-images`
- **Hosting:** Git repo at `C:\isoSandBox`

### Supabase
```
Project ID:  jyfaegmnzkarlcximxjo
URL:         https://jyfaegmnzkarlcximxjo.supabase.co
Anon key:    sb_publishable_-JI4Y3ImXzqRVkwx1yIL1g_rVJVx5bn
Client:      window._sb = window.supabase.createClient(url, key)
```

### Database Tables
| Table | Purpose |
|---|---|
| `2026_series1_baseball` | Set catalog — 2026 Topps Series 1 |
| `2026_heritage_baseball` | Set catalog — 2026 Topps Heritage |
| `2025_stadium_club_v2` | Set catalog — 2025 Stadium Club |
| `cards` | Legacy card reference |
| `vault` | User card holdings |
| `isos` | ISO posts |
| `matches` | ISO matches |
| `profiles` | User profiles |
| `credit_events` | ISO credit ledger |
| `notifications` | User notifications |
| `seller_preferences` | Seller settings |
| `price_flags` | Anomalous price submissions for admin review |
| `price_flag_emails` | Email log for price flag notifications |
| `error_reports` | User-submitted card data errors |

---

## FILE MAP
```
C:\isoSandBox\
  dashboard.html          ← entire app (4337 lines)
  card-viewer.html        ← 3D card viewer — NEVER TOUCH
  SPRINGBOARD.md          ← session handoff notes
  PROJECT.md              ← this file
```

---

## NAVIGATION PANELS
```
overview      Market overview, stats
post          New ISO post (multi-step)
myisos        User's active ISOs
market        Market browser
myvault       User's vault + ROI
library       ISOVault search engine
carddetail    Card detail view (from ISOVault)
admin-price   Admin price flag queue
isoticker     ISO ticker feed
notifs        Notifications
leaderboard   Leaderboard
account       Account settings
```

Nav function: `N('panelId', navEl)` — switches active panel.

---

## ISOVAULT ARCHITECTURE

### Flow
```
Home (sport grid)
  → ivSelectSport(sportId)
  → Set browser (year/brand pills + set tiles)
  → ivSelectSet(table)
  → Card list (checklist or grid)
  → ivOpenCard(row) or openCardDetail(id)
  → Card detail panel
```

### Key globals
```javascript
_ivInited        // init guard
_ivSport         // active sport id
_ivSet           // active set def object
_ivData          // raw rows from Supabase
_ivFiltered      // filtered rows
_ivCat           // category filter
_ivSearch        // search string
_ivView          // 'list' | 'grid'
_ivCounts        // { [table]: count }
_ivMarketCache   // { [card_number]: price }
window._ivRowCache  // { [idx]: row } — for click delegation
```

### IV_SETS registry
```javascript
{ table:'2026_series1_baseball',  sport:'baseball', year:2026, brand:'Topps', name:'Series 1',     label:'2026 Topps Series 1' }
{ table:'2026_heritage_baseball', sport:'baseball', year:2026, brand:'Topps', name:'Heritage',     label:'2026 Topps Heritage' }
{ table:'2025_stadium_club_v2',   sport:'baseball', year:2025, brand:'Topps', name:'Stadium Club', label:'2025 Stadium Club'   }
```

### Card row click — how it works
1. Single `onclick` delegate on `#ivCardList`
2. `e.target.closest('[data-rowidx]')` finds clicked row
3. `window._ivRowCache[idx]` retrieves the row data
4. `ivOpenCard(row)` — checks CARDS array for known entry
5. If found: stashes `window._cdOverrideCardNum` + `window._cdOverrideVarImages` from the DB row, then calls `openCardDetail(known.id)`
6. If not found: builds ad-hoc card object, navigates directly

### Image lookup fix (critical)
- ISOVault rows use sequential `card_number` (e.g. `135`)
- CARDS entries use set card numbers (e.g. `SS-24`)
- `_cdLoadCatalogImages` checks `window._cdOverrideVarImages` first — uses preloaded `var_images` from the clicked row directly, bypassing the Supabase query when possible

---

## CARD DETAIL — VAULT PATHS

**Path 1 — No catalog pic:**  
User uploads front + back → fills acquisition data + price paid

**Path 2 — Has catalog pic:**  
Acquisition data + price paid only, no upload needed

**Price paid is MANDATORY on both paths** — feeds the market value engine.

---

## MARKET VALUE ENGINE
- Pulls last N sales per variation from `vault` table
- Caches in `window._ivMarketCache` keyed by `card_number`
- ±40% deviation from market avg → silent flag → `price_flags` table
- Admin reviews at `/admin/price` panel
- Admin actions: Fix price / Send email / Mark confirmed / User self-corrects
- Self-correction by user → +1 ISO credit auto-awarded

---

## ERROR REPORTING
- Any user can report a card data error from the card detail panel
- 5 ISO credits awarded to reporter if admin confirms the fix
- Stored in `error_reports` table

---

## CREDITS SYSTEM
```
Base cost:          5 credits per ISO post
Free credits:       5 on signup
Error finder's fee: +5 credits when report confirmed
Self-correction:    +1 credit
```

---

## GRIFFEY SS-24 (id:50) — CARDS ARRAY ENTRY
```javascript
{
  id:50, player:'Ken Griffey Jr.', year:2025, brand:'Topps', set:'Stadium Club',
  parallel:'Base', cardNum:'#SS-24', hasCatalogPic:false,
  _setTable:'2025_stadium_club_v2', _cardNumber:'SS-24', _team:'Seattle Mariners',
  variations: [18 total — Base, Red Foil, Sepia, Black & White, ..., SuperFractor 1/1]
}
```
CARDS array has ids 1–50. Was broken by a stray lone `,` before id:50 creating a sparse array undefined slot — fixed 2026-03-13.

---

## BUILD STAMP FORMAT
```
[SYS] GrailISO_v1.1.7 :: BUILD {YYYYMMDD} {HH:MM} :: STABLE
```

---

## PENDING MIGRATIONS (run in Supabase SQL editor)
```sql
ALTER TABLE vault ADD COLUMN IF NOT EXISTS variation text;
ALTER TABLE vault ADD COLUMN IF NOT EXISTS market_excluded boolean DEFAULT false;

CREATE TABLE price_flags ( ... );   -- see SPRINGBOARD.md for full SQL
CREATE TABLE price_flag_emails ( ... );
CREATE TABLE error_reports ( ... );
```

---

## PENDING WORK
- [ ] Replace Discord placeholder URLs (4 sports)
- [ ] Remove debug `[IV]` / `[CD]` console.log lines before production
- [ ] Run pending SQL migrations
- [ ] `/admin/fomo` dashboard — NOT YET
- [ ] Additional set tables (basketball, football, hockey, soccer, golf, wrestling)
- [ ] Real user auth (currently using hardcoded JM profile)
